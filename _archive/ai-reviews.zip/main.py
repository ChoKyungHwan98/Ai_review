"""리뷰 분석 API - FastAPI 메인 앱

실행: uvicorn main:app --reload
문서: http://127.0.0.1:8000/docs
"""

from fastapi import FastAPI, HTTPException
from contextlib import asynccontextmanager

from models import (
    ReviewCreate, ReviewResponse,
    AnalyzeRequest, AnalysisResponse,
    StatsResponse,
)
from database import (
    init_database,
    create_review, get_review, get_all_reviews,
    save_analysis, get_analysis,
    get_stats,
)
from analyzer import analyze_review


@asynccontextmanager
async def lifespan(app: FastAPI):
    # 앱 시작 시 DB 초기화
    init_database()
    yield


app = FastAPI(
    title="리뷰 분석 API",
    description="게임 리뷰를 저장하고 LLM으로 분석하는 API",
    version="1.0.0",
    lifespan=lifespan,
)


@app.get("/", summary="헬스체크", description="서버 상태 확인")
def root():
    return {"message": "리뷰 분석 API", "status": "running", "version": "1.0.0"}


@app.get(
    "/reviews",
    response_model=list[ReviewResponse],
    summary="리뷰 목록 조회",
    description="저장된 모든 리뷰를 최신순으로 반환합니다.",
)
def list_reviews():
    return get_all_reviews()


@app.post(
    "/reviews",
    response_model=ReviewResponse,
    summary="리뷰 추가",
    description="새 리뷰를 DB에 저장하고 저장된 리뷰를 반환합니다.",
)
def add_review(review: ReviewCreate):
    review_id = create_review(content=review.content, game_name=review.game_name)
    return get_review(review_id)


@app.post(
    "/analyze",
    response_model=AnalysisResponse,
    summary="분석 실행",
    description="특정 리뷰를 LLM(OpenRouter)에 보내 감성/키워드/확신도를 분석합니다.",
)
def run_analysis(request: AnalyzeRequest):
    review = get_review(request.review_id)
    if not review:
        raise HTTPException(status_code=404, detail="리뷰를 찾을 수 없습니다")

    try:
        analysis = analyze_review(review["content"])
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"분석 실패: {str(e)}")

    save_analysis(
        review_id=request.review_id,
        sentiment=analysis["sentiment"],
        keywords=analysis["keywords"],
        confidence=analysis["confidence"],
    )
    return get_analysis(request.review_id)


@app.get(
    "/analysis/{review_id}",
    response_model=AnalysisResponse,
    summary="분석 결과 조회",
    description="특정 리뷰 ID에 대한 분석 결과를 조회합니다.",
)
def get_analysis_result(review_id: int):
    result = get_analysis(review_id)
    if not result:
        raise HTTPException(status_code=404, detail="분석 결과가 없습니다.")
    return result


@app.get(
    "/stats",
    response_model=StatsResponse,
    summary="통계 조회",
    description="전체 리뷰 수, 분석된 리뷰 수, 감성별 분포를 반환합니다.",
)
def get_statistics():
    return get_stats()
