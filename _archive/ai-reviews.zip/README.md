# 리뷰 분석 API (37·40차시 프로젝트)

게임 리뷰를 SQLite DB에 저장하고, OpenRouter LLM으로 감성 분석하는 FastAPI 서버.

## 📁 프로젝트 구조

```
ai-reviews/
├── main.py                       # FastAPI 앱 (엔드포인트 6개)
├── database.py                   # DB 연결 및 CRUD
├── analyzer.py                   # LLM 분석 (OpenRouter)
├── models.py                     # Pydantic 모델
├── db_practice.py                # 37차시 DB 구축 실습 스크립트
├── test_api.py                   # API 자동 테스트
├── requirements.txt              # 패키지 목록
├── .env.example                  # 환경변수 템플릿
├── .env                          # 실제 환경변수 (Git 미포함)
├── .gitignore
└── README.md
```

## 🚀 실행 방법

### 1. 가상환경 활성화 + 패키지 설치

```powershell
# PowerShell
cd C:\Users\Admin\Desktop\게임기획\포트폴리오\ai-reviews
.\venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

### 2. .env 파일에 OpenRouter API 키 입력

`.env` 파일을 열어서 실제 키로 교체:

```
OPENROUTER_API_KEY=sk-or-v1-<발급받은-실제-키>
```

> ※ API 키 발급: https://openrouter.ai/keys
> ※ `.env`는 `.gitignore`에 포함되어 있어 Git에 올라가지 않습니다.

### 3-A. DB 구축 실습 실행 (37차시 산출물)

```powershell
python db_practice.py
```

- 산출물: `review_analysis_practice.db`
- 출력: 테이블 생성 / INSERT / SELECT / WHERE / GROUP BY / JOIN / UPDATE 결과

### 3-B. FastAPI 서버 실행 (40차시 산출물)

```powershell
uvicorn main:app --reload
```

- 서버 주소: http://127.0.0.1:8000
- **Swagger 문서: http://127.0.0.1:8000/docs**
- ReDoc: http://127.0.0.1:8000/redoc

### 4. API 자동 테스트 (선택)

서버가 켜진 상태에서 별도 터미널:

```powershell
python test_api.py
```

---

## 📚 API 엔드포인트 (6개)

| Method | Path                  | 설명                              |
|--------|-----------------------|-----------------------------------|
| GET    | `/`                   | 헬스체크                          |
| GET    | `/reviews`            | 리뷰 목록 조회                    |
| POST   | `/reviews`            | 리뷰 추가                         |
| POST   | `/analyze`            | LLM 분석 실행                     |
| GET    | `/analysis/{id}`      | 분석 결과 조회                    |
| GET    | `/stats`              | 통계 (총 리뷰/분석된 수/감성 분포) |

### 요청/응답 예시

**POST /reviews**
```json
요청: {"content": "정말 재밌는 게임이에요!", "game_name": "팰월드"}
응답: {"id": 1, "content": "정말 재밌는 게임이에요!", "game_name": "팰월드", "created_at": "2026-05-17 12:00:00"}
```

**POST /analyze**
```json
요청: {"review_id": 1}
응답: {"review_id": 1, "sentiment": "긍정", "keywords": ["재미", "스토리"], "confidence": 0.92, "analyzed_at": "..."}
```

**GET /stats**
```json
응답: {"total_reviews": 8, "analyzed_count": 8, "sentiment_distribution": {"긍정": 5, "부정": 3}}
```

---

## 🗄️ DB 스키마

### reviews
| 컬럼          | 타입    | 설명                |
|---------------|---------|---------------------|
| id            | INTEGER | PK, AUTOINCREMENT   |
| content       | TEXT    | NOT NULL, 리뷰 내용 |
| game_name     | TEXT    | 게임 이름           |
| created_at    | TEXT    | 작성 시간 (default) |

### analysis_results
| 컬럼          | 타입    | 설명                                  |
|---------------|---------|---------------------------------------|
| id            | INTEGER | PK                                    |
| review_id     | INTEGER | UNIQUE, **FK → reviews(id)**          |
| sentiment     | TEXT    | 긍정 / 부정 / 중립                    |
| keywords      | TEXT    | 쉼표 구분 키워드                      |
| confidence    | REAL    | 0.0 ~ 1.0 확신도                      |
| analyzed_at   | TEXT    | 분석 시간                             |

---

## ✅ Day 5 평가 기준 대조

| 항목            | 기준                              | 충족 여부 |
|-----------------|-----------------------------------|-----------|
| 엔드포인트 수   | 5개 이상                          | ✅ 6개    |
| GET 동작        | 3개 모두 정상                     | ✅ `/`, `/reviews`, `/analysis/{id}`, `/stats` |
| POST 동작       | 2개 정상 + 검증 로직              | ✅ `/reviews`, `/analyze` + Pydantic 자동 검증 |
| DB 연동         | 조회 + 저장 + 트랜잭션            | ✅ commit/close, FOREIGN KEY |
| API 문서        | `/docs` 정상 + 상세 설명          | ✅ summary/description 명시 |

---

## 🔐 보안 체크

- [x] `.env` 가 `.gitignore`에 포함됨
- [x] API 키가 코드에 하드코딩되어 있지 않음 (`os.getenv` 사용)
- [x] `.env.example`로 형식만 공유

---

## 🧭 다음 단계 (확장 아이디어)

- 팰월드 스팀 리뷰 수집 → `/reviews`로 일괄 등록
- 일괄 분석 엔드포인트(`POST /analyze/batch`) 추가
- 분석 결과 CSV 다운로드 엔드포인트 추가
